The raw data files of your STOP-IT experiment can be placed in this folder. 
